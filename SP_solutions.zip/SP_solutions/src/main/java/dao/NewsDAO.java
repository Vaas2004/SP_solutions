package dao;

import java.sql.*;
import java.util.*;
import java.util.Locale.Category;

import Utility.DBUtil;
import model.*;

public class NewsDAO {
    private Connection conn;

    public NewsDAO() throws Exception {
        conn = DBUtil.getConnection();
    }

    public List<Category> getAllCategories() throws Exception {
        List<Category> list = new ArrayList<>();
        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery("SELECT * FROM Category");
        while (rs.next()) {
            Category c = new Category();
            c.setId(rs.getInt("CategoryID"));
            c.setName(rs.getString("Name"));
            list.add(c);
        }
        return list;
    }

    public List<News> getNewsByCategory(int categoryId) throws Exception {
        List<News> list = new ArrayList<>();
        String sql = "SELECT n.* FROM News n JOIN News_Category nc ON n.NewsID = nc.NewsID WHERE nc.CategoryID=?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, categoryId);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            News n = new News();
            n.setId(rs.getInt("NewsID"));
            n.setTitle(rs.getString("Title"));
            n.setContent(rs.getString("Content"));
            n.setPublishDate(rs.getTimestamp("PublishDate"));
            list.add(n);
        }
        return list;
    }

    public News getNewsById(int newsId) throws Exception {
        String sql = "SELECT * FROM News WHERE NewsID=?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, newsId);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            News n = new News();
            n.setId(rs.getInt("NewsID"));
            n.setTitle(rs.getString("Title"));
            n.setContent(rs.getString("Content"));
            n.setPublishDate(rs.getTimestamp("PublishDate"));
            return n;
        }
        return null;
    }

    public List<Comment> getCommentsByNews(int newsId) throws Exception {
        List<Comment> list = new ArrayList<>();
        String sql = "SELECT * FROM Comment WHERE NewsID=? ORDER BY CommentDate DESC";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, newsId);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            Comment c = new Comment();
            c.setId(rs.getInt("CommentID"));
            c.setText(rs.getString("CommentText"));
            c.setCommentDate(rs.getTimestamp("CommentDate"));
            list.add(c);
        }
        return list;
    }

    public void addComment(int newsId, String text) throws Exception {
        String sql = "INSERT INTO Comment (NewsID, CommentText) VALUES (?, ?)";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setInt(1, newsId);
        ps.setString(2, text);
        ps.executeUpdate();
    }
}