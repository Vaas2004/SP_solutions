package model;

public class Category {
    private int id;
    private String name;

    // Getters and setters
}